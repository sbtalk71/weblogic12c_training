package com.demo.lib;

public class Util {
	public int add(int a, int b) {
		System.out.println(" inside shared lib add method");
		return a + b;
	}

	public int multiply(int a, int b) {
		System.out.println(" inside shared lib multiply method");
		return a * b;
	}

	public String greet(String name) {

		System.out.println(" inside shared lib greet method");
		return "Hello " + name;
	}
}
